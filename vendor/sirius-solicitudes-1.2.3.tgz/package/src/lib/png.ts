/**
 * Comprobación de que un PNG llegó entero.
 *
 * Existe por un fallo que no avisa: `doc.embedPng()` de pdf-lib 1.17.1 **no lanza**
 * con un PNG cortado —cabecera válida, IDAT incompleto—, sino que se queda en un
 * bucle dentro del inflate de UPNG. Ningún `try/catch` lo ataja: la función muere
 * por timeout con el permiso ya creado y sin documento. Pasó con la firma
 * institucional cuando `FIRMA_GESTION_SER_BASE64` quedó cortada en un despliegue,
 * y puede pasar con cualquier firma que llegue del navegador o de S3.
 *
 * Mirar solo los bytes «PNG» de la cabecera no basta: un PNG cortado los tiene.
 * Aquí se recorren los chunks y se exige que el archivo termine en IEND.
 */

import { base64ABytes } from "./bytes";

const FIRMA_PNG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];

/**
 * `true` si una firma en base64 (sin prefijo `data:`) es un PNG completo.
 * Para validar lo que manda el navegador antes de archivarlo y de llevarlo al PDF.
 */
export function firmaBase64Completa(base64: unknown): boolean {
  if (typeof base64 !== "string" || !base64) return false;
  try {
    return pngCompleto(base64ABytes(base64));
  } catch {
    return false; // atob lanza con caracteres fuera de base64
  }
}

/** `true` si los bytes son un PNG que empieza en IHDR, tiene todos sus chunks completos y llega a IEND. */
export function pngCompleto(bytes: Uint8Array | null | undefined): boolean {
  if (!bytes || bytes.length < FIRMA_PNG.length + 12) return false;
  for (let i = 0; i < FIRMA_PNG.length; i++) {
    if (bytes[i] !== FIRMA_PNG[i]) return false;
  }

  const vista = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let offset = FIRMA_PNG.length;
  let primero = true;

  // Cada chunk: largo (4) + tipo (4) + datos (largo) + CRC (4).
  while (offset + 12 <= bytes.length) {
    const largo = vista.getUint32(offset);
    const tipo = String.fromCharCode(
      bytes[offset + 4], bytes[offset + 5], bytes[offset + 6], bytes[offset + 7],
    );
    const fin = offset + 12 + largo;
    if (fin > bytes.length) return false; // chunk cortado
    if (primero && tipo !== "IHDR") return false;
    primero = false;
    // Bytes sobrantes tras IEND no rompen el decodificador: se aceptan.
    if (tipo === "IEND") return true;
    offset = fin;
  }
  return false; // se acabaron los bytes sin llegar a IEND
}
