import { describe, expect, it } from "vitest";
import { firmaBase64Completa, pngCompleto } from "./png";
import { FIRMA_FIXTURE_BASE64 } from "../pdf/firma-fixture";

const bytes = Buffer.from(FIRMA_FIXTURE_BASE64, "base64");

describe("pngCompleto", () => {
  it("acepta un PNG entero", () => {
    expect(pngCompleto(new Uint8Array(bytes))).toBe(true);
  });

  it("rechaza un PNG cortado aunque conserve la cabecera", () => {
    // Es el caso que dejaba a pdf-lib en bucle: firma «PNG» intacta, IDAT a medias.
    for (const proporcion of [0.9, 0.5, 0.3]) {
      const cortado = bytes.subarray(0, Math.floor(bytes.length * proporcion));
      expect(cortado.subarray(1, 4).toString("latin1")).toBe("PNG");
      expect(pngCompleto(new Uint8Array(cortado))).toBe(false);
    }
  });

  it("rechaza lo que no es PNG", () => {
    expect(pngCompleto(new Uint8Array([1, 2, 3]))).toBe(false);
    expect(pngCompleto(null)).toBe(false);
  });
});

describe("firmaBase64Completa", () => {
  it("valida la firma tal como la manda el formulario (base64 sin prefijo)", () => {
    expect(firmaBase64Completa(FIRMA_FIXTURE_BASE64)).toBe(true);
  });

  it("rechaza una firma cortada, con prefijo data: o que no es texto", () => {
    expect(firmaBase64Completa(FIRMA_FIXTURE_BASE64.slice(0, 300))).toBe(false);
    expect(firmaBase64Completa(`data:image/png;base64,${FIRMA_FIXTURE_BASE64}`)).toBe(false);
    expect(firmaBase64Completa(undefined)).toBe(false);
  });
});
